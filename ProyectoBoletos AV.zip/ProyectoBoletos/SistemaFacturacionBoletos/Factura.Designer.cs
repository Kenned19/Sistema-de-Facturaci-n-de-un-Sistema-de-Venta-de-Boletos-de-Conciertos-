﻿namespace CPresentacion
{
    partial class Factura
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            textBox9 = new TextBox();
            textBox10 = new TextBox();
            textBox11 = new TextBox();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            label17 = new Label();
            comboBox1 = new ComboBox();
            comboBox2 = new ComboBox();
            textBox12 = new TextBox();
            textBox13 = new TextBox();
            dataGridView1 = new DataGridView();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            label18 = new Label();
            label19 = new Label();
            label20 = new Label();
            label21 = new Label();
            label22 = new Label();
            textBox14 = new TextBox();
            textBox15 = new TextBox();
            textBox16 = new TextBox();
            textBox17 = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(37, 9);
            label1.Name = "label1";
            label1.Size = new Size(96, 15);
            label1.TabIndex = 0;
            label1.Text = "Datos del Cliente";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 34);
            label2.Name = "label2";
            label2.Size = new Size(44, 15);
            label2.TabIndex = 1;
            label2.Text = "Cliente";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 89);
            label3.Name = "label3";
            label3.Size = new Size(52, 15);
            label3.TabIndex = 2;
            label3.Text = "Telefono";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 61);
            label4.Name = "label4";
            label4.Size = new Size(44, 15);
            label4.TabIndex = 3;
            label4.Text = "Cedula";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 115);
            label5.Name = "label5";
            label5.Size = new Size(43, 15);
            label5.TabIndex = 4;
            label5.Text = "Correo";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(62, 31);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(142, 23);
            textBox1.TabIndex = 5;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(62, 60);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(142, 23);
            textBox2.TabIndex = 6;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(62, 89);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(142, 23);
            textBox3.TabIndex = 7;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(62, 118);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(142, 23);
            textBox4.TabIndex = 8;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(409, 9);
            label10.Name = "label10";
            label10.Size = new Size(97, 15);
            label10.TabIndex = 17;
            label10.Text = "Datos de la Venta";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(223, 39);
            label11.Name = "label11";
            label11.Size = new Size(38, 15);
            label11.TabIndex = 18;
            label11.Text = "Fecha";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(223, 68);
            label12.Name = "label12";
            label12.Size = new Size(63, 15);
            label12.TabIndex = 19;
            label12.Text = "Factura N*";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(223, 97);
            label13.Name = "label13";
            label13.Size = new Size(95, 15);
            label13.TabIndex = 20;
            label13.Text = "Metodo de Pago";
            // 
            // textBox9
            // 
            textBox9.Location = new Point(324, 31);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(127, 23);
            textBox9.TabIndex = 21;
            // 
            // textBox10
            // 
            textBox10.Location = new Point(324, 63);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(127, 23);
            textBox10.TabIndex = 22;
            // 
            // textBox11
            // 
            textBox11.Location = new Point(324, 92);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(127, 23);
            textBox11.TabIndex = 23;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(466, 29);
            label14.Name = "label14";
            label14.Size = new Size(59, 15);
            label14.TabIndex = 24;
            label14.Text = "Concierto";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(466, 58);
            label15.Name = "label15";
            label15.Size = new Size(67, 15);
            label15.TabIndex = 25;
            label15.Text = "Tipo Boleto";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(466, 92);
            label16.Name = "label16";
            label16.Size = new Size(40, 15);
            label16.TabIndex = 26;
            label16.Text = "Precio";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(466, 121);
            label17.Name = "label17";
            label17.Size = new Size(55, 15);
            label17.TabIndex = 27;
            label17.Text = "Cantidad";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(531, 29);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(121, 23);
            comboBox1.TabIndex = 28;
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(531, 58);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(121, 23);
            comboBox2.TabIndex = 29;
            // 
            // textBox12
            // 
            textBox12.Location = new Point(531, 89);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(121, 23);
            textBox12.TabIndex = 30;
            // 
            // textBox13
            // 
            textBox13.Location = new Point(531, 118);
            textBox13.Name = "textBox13";
            textBox13.Size = new Size(121, 23);
            textBox13.TabIndex = 31;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(11, 272);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(536, 166);
            dataGridView1.TabIndex = 32;
            // 
            // button1
            // 
            button1.Location = new Point(577, 297);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 33;
            button1.Text = "Agregar";
            button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(577, 343);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 34;
            button2.Text = "Editar";
            button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Location = new Point(577, 390);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 35;
            button3.Text = "Eliminar";
            button3.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(37, 160);
            label18.Name = "label18";
            label18.Size = new Size(76, 15);
            label18.TabIndex = 36;
            label18.Text = "Datos Finales";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(11, 214);
            label19.Name = "label19";
            label19.Size = new Size(63, 15);
            label19.TabIndex = 37;
            label19.Text = "Descuento";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(11, 190);
            label20.Name = "label20";
            label20.Size = new Size(55, 15);
            label20.TabIndex = 38;
            label20.Text = "Sub Total";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(21, 243);
            label21.Name = "label21";
            label21.Size = new Size(24, 15);
            label21.TabIndex = 39;
            label21.Text = "IVA";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(182, 214);
            label22.Name = "label22";
            label22.Size = new Size(32, 15);
            label22.TabIndex = 40;
            label22.Text = "Total";
            // 
            // textBox14
            // 
            textBox14.Location = new Point(72, 185);
            textBox14.Name = "textBox14";
            textBox14.Size = new Size(100, 23);
            textBox14.TabIndex = 41;
            // 
            // textBox15
            // 
            textBox15.Location = new Point(72, 214);
            textBox15.Name = "textBox15";
            textBox15.Size = new Size(100, 23);
            textBox15.TabIndex = 42;
            // 
            // textBox16
            // 
            textBox16.Location = new Point(72, 243);
            textBox16.Name = "textBox16";
            textBox16.Size = new Size(100, 23);
            textBox16.TabIndex = 43;
            // 
            // textBox17
            // 
            textBox17.Location = new Point(223, 211);
            textBox17.Name = "textBox17";
            textBox17.Size = new Size(100, 23);
            textBox17.TabIndex = 44;
            // 
            // Factura
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(664, 450);
            Controls.Add(textBox17);
            Controls.Add(textBox16);
            Controls.Add(textBox15);
            Controls.Add(textBox14);
            Controls.Add(label22);
            Controls.Add(label21);
            Controls.Add(label20);
            Controls.Add(label19);
            Controls.Add(label18);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(dataGridView1);
            Controls.Add(textBox13);
            Controls.Add(textBox12);
            Controls.Add(comboBox2);
            Controls.Add(comboBox1);
            Controls.Add(label17);
            Controls.Add(label16);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(textBox11);
            Controls.Add(textBox10);
            Controls.Add(textBox9);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Factura";
            Text = "Factura";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private TextBox textBox9;
        private TextBox textBox10;
        private TextBox textBox11;
        private Label label14;
        private Label label15;
        private Label label16;
        private Label label17;
        private ComboBox comboBox1;
        private ComboBox comboBox2;
        private TextBox textBox12;
        private TextBox textBox13;
        private DataGridView dataGridView1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Label label18;
        private Label label19;
        private Label label20;
        private Label label21;
        private Label label22;
        private TextBox textBox14;
        private TextBox textBox15;
        private TextBox textBox16;
        private TextBox textBox17;
    }
}